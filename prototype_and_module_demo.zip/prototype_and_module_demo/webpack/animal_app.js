var Cat = require('./cat');

var c = new Cat("Meowth");

console.log(c.name);

