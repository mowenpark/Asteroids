function Animal(name) {
  this.name = name;
}

module.exports = Animal;
