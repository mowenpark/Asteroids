(function () {
  console.log("hello");
  var a = 10;
  console.log(a);

  function Cat (name) {this.name = name};
  window.message = "Hello";
})();

